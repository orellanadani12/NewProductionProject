create unique index EMPLOYEE_NAME_UINDEX
    on EMPLOYEE (NAME);

